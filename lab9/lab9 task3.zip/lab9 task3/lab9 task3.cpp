#include <iostream>
#include "Book.h"
using namespace std;

class Library {
private:
    Book books[10];
    int count;

public:
	Library():count(0){
	};
    void addBook(const Book& book) {
        if (count>=10){
            cout<<"Library is full.\n";
        }
        books[count++]=book;
        cout<<"book has been added.\n";
    }
    void removeBook(const string& isbn){
        for (int i=0;i<count;i++){
            if (books[i].getISBN()==isbn){
                books[i]=books[count-1];
                --count;
                cout<<"book has been removed.\n";
                return;
            }
        }
        cout<<"book not found\n";
    }
    void searchBook(const string& isbn) const {
        for (int i = 0; i < count; ++i) {
            if (books[i].getISBN() == isbn) {
                cout<<"Title: "<<books[i].getTitle()<<endl;
                cout<<"author: "<<books[i].getAuthor()<<endl;
                cout<<"ISBN: "<<books[i].getISBN()<<endl;
                return;
            }
        }
        cout<<"book not found"<<endl;
    }
};

int main(){
    Library lib;
    lib.addBook(Book("harry potter", "JK Rowling", "978-0451524935"));
    lib.addBook(Book("The Cruel King", "Holly Black", "978-0060850524"));
    lib.addBook(Book("shatter Me", "Tereh Fehmi", "978-0451524935"));
    lib.searchBook("978-0060850524");
   lib.removeBook("978-0451524935");
    return 0;
}
