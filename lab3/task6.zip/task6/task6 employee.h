#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
using namespace std;

class Employee{
	string name;
	int m_salary;
	float taxPercentage;
	public:

    void get_data(string n, int s, float tp);
    void salary_after_tax();
    void update_tax_percentage();
};

#endif 
