#include <iostream>
#include "Employee.h"
using namespace std;

int main()
{
	Employee e1, e2, e3;
	cout<<"enter data for employee 1:"<<endl;
	e1.get_data();
	e1.salary_after_tax();
	e1.update_tax_percentage();
	cout<<"enter data for employee 2:"<<endl;
	e2.get_data();
	e2.salary_after_tax();
	e2.update_tax_percentage();
	cout<<"enter data for employee 3:"<<endl;
	e3.get_data();
	e3.salary_after_tax();
	e3.update_tax_percentage();
	
}