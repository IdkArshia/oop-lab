#include "Employee.h"
#include <iostream>
using namespace std;

class Employee{
	string name;
	int m_salary;
	float taxPercentage;
	public:
		void get_data()
		{
			string n;
			int s;
			float tp;
			cout<<"Name: ";
			cin>>n;
			name=n;
			cout<<"salary: ";
			cin>>s;
			m_salary=s;
			cout<<"tax percentage: ";
			cin>>tp;
			taxPercentage=tp;
		}
		void salary_after_tax()
		{
			cout<<"reamaining salary after tax reduction: Rs."<<(m_salary-(m_salary*(taxPercentage/100)))<<endl;
		}
		void update_tax_percentage()
		{
			float upd;
			cout<<"enter updated tax percentage: ";
			cin>>upd;
			taxPercentage=upd;
			cout<<"remaining salary after updated tax percentage reduction:  Rs."<<m_salary-(m_salary*(upd/100));
			
		}
};